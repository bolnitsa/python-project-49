### Hexlet tests and linter status:
[![Actions Status](https://github.com/bolnitsa/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/bolnitsa/python-project-49/actions)
<a href="https://codeclimate.com/github/bolnitsa/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/160cc91c6438b20afdac/maintainability" /></a>
<a href="https://codeclimate.com/github/bolnitsa/python-project-49/test_coverage"><img src="https://api.codeclimate.com/v1/badges/160cc91c6438b20afdac/test_coverage" /></a>
### игры запускаются по коммандам brain-even, brain-calc, brain-gcd, brain-progression, brain-prime  
[Смотреть запись на asciinema (brain-even)](https://asciinema.org/a/9ZKVSCdXvjUqher7pcgnOHRZO)
[Cмотреть запись на asciinema (brain-calc)](https://asciinema.org/a/WbzhFeqx4daPIwtqPvzJ4kU8j)
[Cмотреть запись на asciinema (brain-gcd)](https://asciinema.org/a/9iPm6SFbwfzfPps02dPazVeBo)
[Смотреть запись на asciinema (brain-progression)](https://asciinema.org/a/S5wW0dDDqggTCJBuTmgm7wd01)
[Cмотреть запись на asciinema(brain-prime)](https://asciinema.org/a/FOErLUueilzGz5Ybm1I6N92gP)
